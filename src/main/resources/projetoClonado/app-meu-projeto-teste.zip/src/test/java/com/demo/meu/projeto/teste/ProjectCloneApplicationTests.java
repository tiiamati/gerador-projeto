package com.demo.projectclone;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectCloneApplicationTests {

	@Test
	void contextLoads() {
	}

}
